=== Easy Tag ===
Contributors: adedoja751
Tags: Tags, SEO
Donate link: thewebcrate.co
Requires at least: 3.0.1
Tested up to: 4.6.1
Stable tag: 4.6.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Easy Tags allow you to quickly link texts to the appropriate tag by making the text bold and the links it to the correct URL.

== Description ==
Easy Tags allow you to quickly link texts to the appropriate tag by making the text bold and the links it to the correct URL.

== Installation ==
Download the plugin from this page.
Save the .zip file to a location on your computer.
Open the WP admin panel, and click \\\"Plugins\\\" -> \\\"Add new\\\".
Click \\\"upload\\\".. then browse to the .zip file downloaded from this page.
Click \\\"Install\\\".. and then \\\"Activate plugin\\\".
OR...

Download the plugin from this page.
Extract the .zip file to a location on your computer.
Use either FTP or your hosts cPanel to gain access to your website file directories.
Browse to the wp-content/plugins directory.
Upload the extracted wp_edit folder to this directory location.
Open the WP admin panel.. click the \\\"Plugins\\\" page.. and click \\\"Activate\\\" under the newly added plugin.


== Frequently Asked Questions ==
Nothing yet

== Screenshots ==
1. Highlight on text
2. Click on Icon
3. Generated URL

== Changelog ==
1.0
Initial plugin version.